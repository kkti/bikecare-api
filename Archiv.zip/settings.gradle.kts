rootProject.name = "bikecare-api"
